import PokemonList from "./(routes)/pokemon/page";

export default function Home() {
  return (
    <div className="home-layout">
      <PokemonList />
    </div>
  );
}
